# Problem session 2

Teams of up to three students had to solve the following problems. They had three hours, and were only allowed to use a single computer.
<ul>
<li><a href="https://open.kattis.com/problems/standings">Biased Standings</a></li>
<li><a href="https://open.kattis.com/problems/gold">Getting Gold</a></li>
<li><a href="https://open.kattis.com/problems/walrusweights">Walrus Weights</a></li>
<li><a href="https://open.kattis.com/problems/cantinaofbabel">Cantina of Babel</a></li>
<li><a href="https://open.kattis.com/problems/closingtheloop">Closing the Loop</a></li>
<li><a href="https://open.kattis.com/problems/dominoes2">Dominoes 2</a></li>
</ul>
