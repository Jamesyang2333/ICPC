# Final exam

At the end of the course there was a four-hour individual final exam. It was as follows.
<h2>Part 1 (35%)</h2>
Solve one of the following problems.
<ul>
	<li><a href="https://open.kattis.com/problems/oddmanout">Odd Man Out</a></li>
	<li><a href="https://open.kattis.com/problems/trik">Trik</a></li>
</ul>
<h2>Part 2 (15%)</h2>
Solve one of the following problems.
<ul>
	<li><a href="https://open.kattis.com/problems/moneymatters">Money Matters</a></li>
</ul>
<h2>Part 3 (15%)</h2>
Solve one of the following problems.
<ul>
	<li><a href="https://open.kattis.com/problems/color">Coloring Socks</a></li>
	<li><a href="https://open.kattis.com/problems/commercials">Radio Commercials</a></li>
</ul>
<h2>Part 4 (15%)</h2>
Solve one of the following problems.
<ul>
	<li><a href="https://open.kattis.com/problems/excursion">Kindergarten Excursion</a></li>
	<li><a href="https://open.kattis.com/problems/register">Primary Register</a></li>
</ul>
<h2>Part 5 (15%)</h2>
Solve one of the following problems.
<ul>
	<li><a href="https://open.kattis.com/problems/freckles">Freckles</a></li>
	<li><a href="https://open.kattis.com/problems/gopher2">Gopher II</a></li>
</ul>
<h2>Part 6 (15%)</h2>
Solve one of the following problems.
<ul>
	<li><a href="https://open.kattis.com/problems/aliens">Stammering Aliens</a></li>
	<li><a href="https://open.kattis.com/problems/lawnmower">Lawn Mower</a></li>
</ul>
