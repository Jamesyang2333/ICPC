# Problem session 1

Teams of up to three students had to solve the following problems. They had three hours, and were only allowed to use a single computer.
<ul>
<li><a href="https://open.kattis.com/problems/equalsumseasy">Equal Sums (Easy)</a></li>
<li><a href="https://open.kattis.com/problems/carrots">Solving for Carrots</a></li>
<li><a href="https://open.kattis.com/problems/pivot">Pivot</a></li>
<li><a href="https://open.kattis.com/problems/guess">Guess the Number</a></li>
<li><a href="https://open.kattis.com/problems/numbersetseasy">Number Sets</a></li>
<li><a href="https://open.kattis.com/problems/engineeringenglish">Engineering English</a></li>
</ul>
