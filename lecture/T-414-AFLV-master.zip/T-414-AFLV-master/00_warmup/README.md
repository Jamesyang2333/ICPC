# Warmup problems

We posted this optional set of problems as a warmup for those who were eager to get started.
<h2>Problems</h2>
<ul>
	<li><a href="https://open.kattis.com/problems/different">A Different Problem</a></li>
	<li><a href="https://open.kattis.com/problems/busnumbers">Bus Numbers</a></li>
	<li><a href="https://open.kattis.com/problems/cold">Cold-puter Science</a></li>
	<li><a href="https://open.kattis.com/problems/hello">Hello World!</a></li>
	<li><a href="https://open.kattis.com/problems/mandelbrot">In or Out</a></li>
        <li><a href="https://open.kattis.com/problems/natrij">Natrij</a></li>
        <li><a href="https://open.kattis.com/problems/pathtracing">Path Tracing</a></li>
        <li><a href="https://open.kattis.com/problems/server">Server</a></li>
</ul>
